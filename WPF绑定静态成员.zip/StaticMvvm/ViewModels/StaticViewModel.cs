﻿using Prism.Commands;
using Prism.Mvvm;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;

namespace StaticMvvm.ViewModels
{
    public static class StaticViewModel
    {
        #region StaticCtor
        static StaticViewModel()
        {
            Message = "This is a Message";
            Number = 666;
        }



        #endregion

        #region StaticMvvm
        //public static event EventHandler<PropertyChangedEventArgs> StaticPropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        public static bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(storage, value))
            {
                return false;
            }
            storage = value;
            RaisePropertyChanged(propertyName);
            return true;
        }

        public static bool SetProperty<T>(ref T storage, T value, Action onChanged, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(storage, value))
            {
                return false;
            }
            storage = value;
            onChanged?.Invoke();
            RaisePropertyChanged(propertyName);
            return true;
        }
        public static void RaisePropertyChanged([CallerMemberName] string propertyName = null) => OnPropertyChanged(new PropertyChangedEventArgs(propertyName));

        public static void OnPropertyChanged(PropertyChangedEventArgs args) => StaticPropertyChanged?.Invoke(null, args);
        #endregion

        #region fileds and properties

        private static string message;
        public static string Message
        {
            get { return message; }
            set { SetProperty(ref message, value); }
        }

        private static double number;
        public static double Number
        {
            get { return number; }
            set { SetProperty(ref number, value); }
        }

        private static DelegateCommand updateSourceCommand;
        public static DelegateCommand UpdateSourceCommand => updateSourceCommand ??= new DelegateCommand(UpdateSource);

        static void UpdateSource()
        {
            Number += 1;
            Message = $"This is a Message,{DateTime.Now:HH:mm:ss.fff}";
        }

        public const string Hello = "HelloWorld";

        public static Guid Id { get; } = Guid.NewGuid();

        #endregion


    }
}
